var app = angular.module('ewdApp', []);



app.controller('indexPgMainHeadingCtrl', function ($scope, $http) {
   $scope.mainheadingdata = mainheadingdata;
   $http({
      method: 'GET',
      url: 'content-folder/index-pg-main-heading-section.json'
   }).then(function (response) {
      console.log(response);
      $scope.mainheadingdata = response.data;
   }, function (error) {
      console.error('Fail to load data', error);
   }
   );

});

app.controller('indexPgFeatureCtrl', function ($scope, $http) {
   $scope.featuredata = featuredata;
   $http({
      method: 'GET',
      url: 'content-folder/index-pg-4-features.json'
   }).then(function (response) {
      console.log(response);
      $scope.featuredata = response.data;
   }, function (error) {
      console.error('Fail to load data', error);
   }
   );

});

app.controller('aboutPgMainHeadingCtrl', function ($scope, $http) {
   $scope.mainheadingdata = mainheadingdata;
   $http({
      method: 'GET',
      url: 'content-folder/about-pg-main-heading-section.json'
   }).then(function (response) {
      console.log(response);
      $scope.mainheadingdata = response.data;
   }, function (error) {
      console.error('Fail to load data', error);
   }
   );

});

app.controller('aboutPgMainContentCtrl', function ($scope, $http) {
   $scope.aboutmaincontent = aboutmaincontent;
   $http({
      method: 'GET',
      url: 'content-folder/about-pg-main-content-section.json'
   }).then(function (response) {
      console.log(response);
      $scope.aboutmaincontent = response.data;
   }, function (error) {
      console.error('Fail to load data', error);
   }
   );

});

app.controller('hwwPgRpContentCtrl', function ($scope, $http) {
   $scope.howweworktext = howweworktext;
   $http({
      method: 'GET',
      url: 'content-folder/hww-img-right-content.json'
   }).then(function (response) {
      console.log(response);
      $scope.howweworktext = response.data;
   }, function (error) {
      console.error('Fail to load data', error);
   }
   );

});

app.controller('contactFormCtrl',function($scope){
   $scope.update = function(cont) {
      console.log(cont);
      if(cont!=null)
      {
         var emailId="baisakhi_b@rediffmail.com";
         var subject="Query about service";
         var message="<strong>Name:</strong>"+cont.name+"<br/><strong>Phone:</strong>"+cont.phone+"<br/><strong>Email Address:</strong>"+cont.email+"<br/><br/>"+cont.message;
         window.open("mailto:"+ emailId + "?subject=" + subject+"&body="+message,"_self");
      }
    };
  
});


app.controller('footerContentCtrl', function ($scope, $http) {
   $scope.header = "";
   $scope.content = "";
   $http({
      method: 'GET',
      url: 'content-folder/footer-expertise-content.json'
   }).then(function (response) {
      console.log(response);
      $scope.header = response.data.heading;
      $scope.content = response.data.content;
   }, function (error) {
      console.error('Fail to load data', error);
      $scope.header = "";
      $scope.content = "";
   });
});