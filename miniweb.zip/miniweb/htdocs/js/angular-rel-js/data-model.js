var featuredata = {
    "ontimedelivery": {
       "heading": "",
       "content": ""
    },
    "freefirstdraft": {
       "heading": "",
       "content": ""
    },
    "strictlyconfidential": {
       "heading": "",
       "content": ""
    },
    "zeroplagiarism": {
       "heading": "",
       "content": ""
    }
 };
 var mainheadingdata={
     "mainheading": {
         "heading":"",
         "followuptext":""
     }	
 };
 var aboutmaincontent={
	"maincontent": {
		"imagelefttext":"",
		"imagebottomtext1":"",
		"imagebottomtext2":"",
		"imagebottombuletpt":[]
	}	
};
var howweworktext={
    "contenttext":{
        "heading":"",
        "content":""
    }
}